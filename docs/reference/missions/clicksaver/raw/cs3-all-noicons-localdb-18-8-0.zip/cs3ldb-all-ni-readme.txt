ClickSaver 3.x.x "ALL" local database without icons, created from AO patch 18.8.0
---------------------------------------------------------------------------------

This database should be useful in any of these cases:

* Your ClickSaver 3.x.x "Not found items" / "Error rate"
  counters are detecting more errors than you can stand.

* You want to skip the database creation process.

* You tried to create the database and for whatever reason
  the process failed.


To install, just copy the All.cdb to the directory where you
installed ClickSaver. You don't need to delete the Tiny.cdb
since ClickSaver tries to use All.cdb first.


For more premade local databases:

http://arpa3.net/ao/clicksaver-premade-local-databases.html


For my last ClickSaver and release notes:

  >>>    http://arpa3.net/ao/clicksaver.html    <<<


Take care,

Javier "Kimi" Arpa
Kimibotokiyo@arpa3.net
http://arpa3.net/anarchy-online/
