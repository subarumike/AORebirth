@echo off
powershell.exe -ExecutionPolicy Bypass -NoExit -File "%~dp0unblock-dll.ps1"
pause