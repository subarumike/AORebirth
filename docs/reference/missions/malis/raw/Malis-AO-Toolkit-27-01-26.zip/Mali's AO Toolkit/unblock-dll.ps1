# Unblock all files in current directory and subdirectories with debugging

Write-Host "Starting unblock process..." -ForegroundColor Cyan
Write-Host "Current directory: $(Get-Location)" -ForegroundColor Cyan
Write-Host ""

$files = Get-ChildItem -Path . -Recurse -File -ErrorAction SilentlyContinue

Write-Host "Found $($files.Count) total files" -ForegroundColor Yellow
Write-Host ""

$unblocked = 0
$failed = 0
$skipped = 0

foreach ($file in $files) {
    try {
        # Check if file is blocked
        $zone = Get-Content -Path $file.FullName -Stream Zone.Identifier -ErrorAction SilentlyContinue
        
        if ($zone) {
            Write-Host "[BLOCKED] Unblocking: $($file.FullName)" -ForegroundColor Yellow
            Unblock-File -Path $file.FullName -ErrorAction Stop
            Write-Host "[SUCCESS] Unblocked: $($file.Name)" -ForegroundColor Green
            $unblocked++
        }
        else {
            Write-Host "[SKIP] Not blocked: $($file.Name)" -ForegroundColor Gray
            $skipped++
        }
    }
    catch {
        Write-Host "[ERROR] Failed to unblock: $($file.Name)" -ForegroundColor Red
        Write-Host "  Error: $($_.Exception.Message)" -ForegroundColor Red
        $failed++
    }
    
    Write-Host ""
}

# Summary
Write-Host "================================" -ForegroundColor Cyan
Write-Host "SUMMARY" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host "Total files processed: $($files.Count)" -ForegroundColor White
Write-Host "Successfully unblocked: $unblocked" -ForegroundColor Green
Write-Host "Skipped (not blocked): $skipped" -ForegroundColor Gray
Write-Host "Failed: $failed" -ForegroundColor Red
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press any key to exit..." -ForegroundColor Yellow
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")